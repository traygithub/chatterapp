import mongoose ,{Schema} from 'mongoose';

const MessageSchema=new mongoose.Schema({
    username:String,
    message:String,
    createdAt:Date,
});

export const ChatMessageModel=mongoose.model('ChatMessgages',MessageSchema);
