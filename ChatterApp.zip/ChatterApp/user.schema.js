import mongoose,{Schema} from 'mongoose';

const UserSchema=new mongoose.Schema({
    username:String,
    connected:Boolean,
});

export const ChatUserModel=mongoose.model('ChatUsers',UserSchema);
